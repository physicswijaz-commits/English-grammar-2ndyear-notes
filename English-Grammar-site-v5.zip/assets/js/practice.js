/* English Grammar — MCQ practice quiz. Logic from the supplied quiz file; screens restyled to this site. */
// ═══════════════════════════════════════════════════════════
//  SAVED DATA (bookmarks + best score per section) — kept on this phone only
// ═══════════════════════════════════════════════════════════
allQuestions.forEach((q,i)=>{ q._i = i; });
let saved = { bm: [], sec: {} };
try { const s = JSON.parse(localStorage.getItem('practiceQuiz')||'null'); if(s && Array.isArray(s.bm) && s.sec) saved = s; } catch(e){}
function persist(){ try { localStorage.setItem('practiceQuiz', JSON.stringify(saved)); } catch(e){} }
function bestText(name){
  const s = saved.sec[name];
  return s ? `Best ${s.best}% · last ${s.last}%` : 'Not tried yet';
}

// ═══════════════════════════════════════════════════════════
//  STATE
// ═══════════════════════════════════════════════════════════
let selectedSections = new Set(sectionDefs.map(s=>s.name));
let shuffleOn = false;
let timerOn = false;
let timerSec = 45;
const PQ = '.pq ';
let quizQuestions = [];
let currentIdx = 0;
let correctCount = 0;
let wrongCount = 0;
let streak = 0;
let maxStreak = 0;
let answered = false;
let bookmarks = new Set(saved.bm);
let userAnswers = [];
let sectionScores = {};
let countdownInterval = null;
let timeLeft = 0;
let reviewMode = false; // bookmark-only?

// ═══════════════════════════════════════════════════════════
//  BUILD WELCOME SCREEN
// ═══════════════════════════════════════════════════════════
function buildSectionGrid(){
  const grid = document.getElementById('section-grid');
  grid.innerHTML = '';
  sectionDefs.forEach(s=>{
    const d = document.createElement('div');
    d.className = 'section-card selected';
    d.dataset.name = s.name;
    d.innerHTML = `${s.icon}<span>${s.name}<small class="pq-best">${bestText(s.name)}</small></span>`;
    const sv = saved.sec[s.name]; if(sv && sv.last < 60) d.classList.add('weak');
    d.onclick = ()=>toggleSection(s.name, d);
    grid.appendChild(d);
  });
}

function toggleSection(name, el){
  if(selectedSections.has(name)){
    selectedSections.delete(name);
    el.classList.remove('selected');
  } else {
    selectedSections.add(name);
    el.classList.add('selected');
  }
  updateStartBtn();
}
function selectAll(){
  selectedSections = new Set(sectionDefs.map(s=>s.name));
  document.querySelectorAll('.section-card').forEach(c=>c.classList.add('selected'));
  updateStartBtn();
}
function clearAll(){
  selectedSections.clear();
  document.querySelectorAll('.section-card').forEach(c=>c.classList.remove('selected'));
  updateStartBtn();
}
function updateStartBtn(){
  document.getElementById('start-btn').disabled = selectedSections.size === 0;
}
function toggleShuffle(){
  shuffleOn = !shuffleOn;
  document.getElementById('shuffle-toggle').classList.toggle('on', shuffleOn);
}
function toggleTimer(){
  timerOn = !timerOn;
  document.getElementById('timer-toggle').classList.toggle('on', timerOn);
  document.getElementById('time-select').classList.toggle('visible', timerOn);
}
buildSectionGrid();

// ═══════════════════════════════════════════════════════════
//  START QUIZ
// ═══════════════════════════════════════════════════════════
let partialRun = false;
function startQuiz(list){
  partialRun = Array.isArray(list);
  timerSec = parseInt(document.getElementById('time-select').value);
  let qs = Array.isArray(list) ? list.slice() : allQuestions.filter(q=>selectedSections.has(q.section));
  const lim = Array.isArray(list) ? 0 : parseInt(document.getElementById('count-select').value);
  if(shuffleOn || lim || Array.isArray(list)) qs = qs.sort(()=>Math.random()-0.5);
  if(lim && qs.length > lim) qs = qs.slice(0, lim);
  quizQuestions = qs;

  currentIdx = 0;
  correctCount = 0;
  wrongCount = 0;
  streak = 0;
  maxStreak = 0;
  userAnswers = new Array(quizQuestions.length).fill(null);
  sectionScores = {};
  quizQuestions.forEach(q=>{ if(!sectionScores[q.section]) sectionScores[q.section]={c:0,t:0}; sectionScores[q.section].t++; });

  showScreen('screen-quiz');
  renderQuestion();
  if(timerOn) document.getElementById('timer-display').style.display='flex';
  else document.getElementById('timer-display').style.display='none';
}
function startBookmarked(){
  const list = allQuestions.filter(q=>bookmarks.has(q._i));
  if(list.length) startQuiz(list);
}
function retryMistakes(){
  const list = quizQuestions.filter((q,i)=>userAnswers[i]!==q.answer);
  if(list.length) startQuiz(list);
}
function updateBmButton(){
  const b = document.getElementById('bm-start'); if(!b) return;
  b.disabled = bookmarks.size === 0;
  b.querySelector('span').textContent = `Practice bookmarked (${bookmarks.size})`;
}
function rebuildGridKeepingSelection(){
  buildSectionGrid();
  document.querySelectorAll('.section-card').forEach(c=>{ if(!selectedSections.has(c.dataset.name)) c.classList.remove('selected'); });
}

// ═══════════════════════════════════════════════════════════
//  RENDER QUESTION
// ═══════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════
//  UNDERLINE HELPER
// ═══════════════════════════════════════════════════════════
function applyUnderline(question) {
  // Matches questions like: "The underlined word/phrase is..." or "The underlined verb is..."
  // and underlines the word/phrase mentioned in the explanation quotes inside the sentence
  if (!/underlined/i.test(question)) return question;

  // Extract the quoted sentence (inside the outer "..." at the start)
  // Pattern: "sentence." The underlined word/phrase is...
  // We look for the word/phrase that is hinted at by the question context
  // Strategy: find all "quoted" segments inside the sentence part, then underline the relevant one.

  // The question format is typically: '"Sentence with target word." The underlined ...'
  // We need to find what word to underline. We look at what comes AFTER "The underlined":
  // e.g. "The underlined word is" → single word
  // "The underlined phrase is" → phrase in quotes inside sentence

  // Extract the main sentence (between the outer quotes)
  const sentenceMatch = question.match(/^["""](.+?)["""]/);
  if (!sentenceMatch) return question;

  const fullSentence = sentenceMatch[1];

  // Find inner quoted word/phrase (e.g. "with great speed")
  const innerQuoteMatch = fullSentence.match(/["""](.+?)["""]/);

  let wordToUnderline = null;

  if (innerQuoteMatch) {
    // The phrase inside inner quotes is what's underlined
    wordToUnderline = innerQuoteMatch[1];
  } else {
    // No inner quotes — look at the explanation part of the question for clues
    // or parse the sentence for the key word based on context
    // Strategy: check what the question says is underlined
    // "The underlined word is" → we look at the explanation text embedded in question
    // Since explanations reference the word, we check what the answer explanation says
    // But we don't have access here. Instead, use a manual map for known patterns.

    // For "Honesty is the best policy" → underline "Honesty"
    // For "She visited Karachi last summer" → underline "Karachi"
    // For "She was filled with joy" → underline "joy"
    // For "Silver is more expensive than copper" → underline "Silver"
    // For "The audience clapped loudly" → underline "audience"
    // For "She kicked the ball hard" → underline "kicked"
    // For "The baby laughed" → underline "laughed"
    // For "He will come tomorrow" → underline "tomorrow"
    // For "She always studies at night" → underline "always"
    // For "Come here immediately" → underline "here"
    // For "He sings beautifully" → underline "beautifully"
    // For "She never eats junk food" → underline "never"

    const manualMap = [
      { hint: 'Honesty is the best policy', word: 'Honesty' },
      { hint: 'She visited Karachi last summer', word: 'Karachi' },
      { hint: 'She was filled with joy', word: 'joy' },
      { hint: 'Silver is more expensive than copper', word: 'Silver' },
      { hint: 'The audience clapped loudly', word: 'audience' },
      { hint: 'She kicked the ball hard', word: 'kicked' },
      { hint: 'The baby laughed', word: 'laughed' },
      { hint: 'He will come tomorrow', word: 'tomorrow' },
      { hint: 'She always studies at night', word: 'always' },
      { hint: 'Come here immediately', word: 'here' },
      { hint: 'He sings beautifully', word: 'beautifully' },
      { hint: 'She never eats junk food', word: 'never' },
      { hint: 'She spoke in a loud voice', word: 'in a loud voice' },
      { hint: 'He runs with great speed', word: 'with great speed' },
      { hint: 'They arrived at midnight', word: 'at midnight' },
    ];

    for (const entry of manualMap) {
      if (fullSentence.includes(entry.hint)) {
        wordToUnderline = entry.word;
        break;
      }
    }
  }

  if (!wordToUnderline) return question;

  // Now rebuild the question string with the underlined word wrapped in <u> inside the sentence
  const underlined = `<u style="text-decoration-color:var(--primary);text-decoration-thickness:2px;font-weight:700;">${wordToUnderline}</u>`;

  // Replace only inside the quoted sentence part
  const newSentence = fullSentence.replace(wordToUnderline, underlined);
  const rebuilt = question.replace(fullSentence, newSentence);

  return rebuilt;
}

function renderQuestion(){
  answered = false;
  const q = quizQuestions[currentIdx];
  const total = quizQuestions.length;

  // progress
  const pct = Math.round((currentIdx/total)*100);
  document.getElementById('progress-fill').style.width = pct+'%';
  document.getElementById('progress-text').textContent = `Question ${currentIdx+1} of ${total}`;
  document.getElementById('progress-pct').textContent = pct+'%';

  // live score
  document.getElementById('ls-correct').textContent = correctCount;
  document.getElementById('ls-wrong').textContent = wrongCount;
  document.getElementById('ls-remaining').textContent = total - currentIdx;
  document.getElementById('ls-streak').textContent = streak+'🔥';

  // section badge
  document.getElementById('q-section-badge').textContent = q.section;

  // question
  document.getElementById('question-num').textContent = `Question ${currentIdx+1}`;
  document.getElementById('question-text').innerHTML = applyUnderline(q.question);

  // bookmark
  const bm = document.getElementById('bookmark-btn');
  bm.classList.toggle('bookmarked', bookmarks.has(q._i));

  // options
  const ol = document.getElementById('options-list');
  ol.innerHTML = '';
  const labels = ['A','B','C','D'];
  q.options.forEach((opt,i)=>{
    const btn = document.createElement('button');
    btn.className = 'mcq-opt option-btn';
    btn.innerHTML = `<span class="mcq-l">${labels[i]}</span><span class="mcq-t">${opt}</span>`;
    btn.onclick = ()=>selectAnswer(i);
    ol.appendChild(btn);
  });

  // explanation
  const exBox = document.getElementById('explanation-box');
  exBox.classList.remove('show');
  exBox.innerHTML = '';

  // next btn
  const nextBtn = document.getElementById('next-btn');
  nextBtn.disabled = true;
  const arrowSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`;
  const flagSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>`;
  nextBtn.innerHTML = currentIdx === total-1 ? `Finish ${flagSvg}` : `Next ${arrowSvg}`;

  // restore previous answer if navigated back (not implemented — forward only)
  if(userAnswers[currentIdx] !== null){
    showAnswerState(userAnswers[currentIdx]);
  }

  // timer
  if(timerOn) startTimer();
}

// ═══════════════════════════════════════════════════════════
//  ANSWER SELECTION
// ═══════════════════════════════════════════════════════════
function selectAnswer(idx){
  if(answered) return;
  answered = true;
  clearCountdown();

  const q = quizQuestions[currentIdx];
  userAnswers[currentIdx] = idx;

  if(idx === q.answer){
    correctCount++;
    streak++;
    maxStreak = Math.max(maxStreak, streak);
    sectionScores[q.section].c++;
  } else {
    wrongCount++;
    streak = 0;
  }

  showAnswerState(idx);
  document.getElementById('next-btn').disabled = false;
  document.getElementById('ls-correct').textContent = correctCount;
  document.getElementById('ls-wrong').textContent = wrongCount;
  document.getElementById('ls-streak').textContent = streak+'🔥';
}

function showAnswerState(selectedIdx){
  const q = quizQuestions[currentIdx];
  const btns = document.querySelectorAll('.option-btn');
  btns.forEach((btn,i)=>{
    btn.disabled = true;
    if(i === q.answer) btn.classList.add('correct');
    else if(i === selectedIdx && selectedIdx !== q.answer) btn.classList.add('wrong');
  });
  const exBox = document.getElementById('explanation-box');
  exBox.innerHTML = `<strong>💡 Explanation:</strong> ${q.explanation}`;
  exBox.classList.add('show');
}

// ═══════════════════════════════════════════════════════════
//  NAVIGATION
// ═══════════════════════════════════════════════════════════
function nextQuestion(){
  clearCountdown();
  if(!answered){
    // auto-skip (no answer given — treat as skipped)
    userAnswers[currentIdx] = -1;
    streak = 0;
  }
  currentIdx++;
  if(currentIdx >= quizQuestions.length){
    showResults();
  } else {
    renderQuestion();
  }
}

function quitQuiz(){
  if(confirm('Quit this quiz? Your progress will be lost.')){
    clearCountdown();
    goHome();
  }
}

// ═══════════════════════════════════════════════════════════
//  TIMER
// ═══════════════════════════════════════════════════════════
function startTimer(){
  timeLeft = timerSec;
  updateTimerDisplay();
  countdownInterval = setInterval(()=>{
    timeLeft--;
    updateTimerDisplay();
    if(timeLeft<=0){
      clearInterval(countdownInterval);
      // auto-next
      if(!answered){
        userAnswers[currentIdx] = -1;
        streak = 0;
        // show correct answer
        const btns = document.querySelectorAll('.option-btn');
        btns.forEach((btn,i)=>{ btn.disabled=true; if(i===quizQuestions[currentIdx].answer) btn.classList.add('correct'); });
        const exBox = document.getElementById('explanation-box');
        exBox.innerHTML = `<strong>⏱ Time\'s up!</strong> ${quizQuestions[currentIdx].explanation}`;
        exBox.classList.add('show');
        answered = true;
        document.getElementById('next-btn').disabled = false;
      }
    }
  },1000);
}
function clearCountdown(){ clearInterval(countdownInterval); }
function updateTimerDisplay(){
  const td = document.getElementById('timer-display');
  const tt = document.getElementById('timer-text');
  const m = Math.floor(timeLeft/60).toString().padStart(2,'0');
  const s = (timeLeft%60).toString().padStart(2,'0');
  tt.textContent = `${m}:${s}`;
  td.classList.toggle('warn', timeLeft<=10);
}

// ═══════════════════════════════════════════════════════════
//  BOOKMARK
// ═══════════════════════════════════════════════════════════
function toggleBookmark(){
  const bm = document.getElementById('bookmark-btn');
  const qi = quizQuestions[currentIdx]._i;
  if(bookmarks.has(qi)){
    bookmarks.delete(qi);
    bm.classList.remove('bookmarked');
  } else {
    bookmarks.add(qi);
    bm.classList.add('bookmarked');
  }
  saved.bm = Array.from(bookmarks); persist(); updateBmButton();
}

// ═══════════════════════════════════════════════════════════
//  KEYBOARD SHORTCUTS
// ═══════════════════════════════════════════════════════════
document.addEventListener('keydown',e=>{
  const screen = document.querySelector('.pq-screen.active').id;
  if(screen !== 'screen-quiz') return;
  if(e.key==='ArrowRight' && !document.getElementById('next-btn').disabled) nextQuestion();
  if(e.key==='b'||e.key==='B') toggleBookmark();
  if(!answered){
    if(e.key==='a'||e.key==='A') selectAnswer(0);
    if(e.key==='b'||e.key==='B') {} // handled above
    if(e.key==='c'||e.key==='C') selectAnswer(2);
    if(e.key==='d'||e.key==='D') selectAnswer(3);
    // re-check B after bookmark collision — only answer if not answered
    if((e.key==='b'||e.key==='B') && !answered) selectAnswer(1);
  }
});

// ═══════════════════════════════════════════════════════════
//  RESULTS
// ═══════════════════════════════════════════════════════════
function showResults(){
  clearCountdown();
  document.getElementById('timer-display').style.display='none';
  const total = quizQuestions.length;
  const pct = Math.round((correctCount/total)*100);

  let grade, title, subtitle, color;
  if(pct>=90){ grade='A+'; title='Exam Ready! 🎉'; subtitle='Outstanding performance — you\'re at the top!'; color='var(--primary)'; }
  else if(pct>=80){ grade='A'; title='Excellent Work! ✅'; subtitle='Great job! Just a little more polish needed.'; color='var(--green)'; }
  else if(pct>=70){ grade='B'; title='Good Work! 📚'; subtitle='Solid understanding — review the missed sections.'; color='var(--accent)'; }
  else if(pct>=60){ grade='C'; title='Needs Revision ⚠️'; subtitle='You\'re on the right track — keep practicing!'; color='var(--gold)'; }
  else { grade='D'; title='Keep Going! 🔄'; subtitle='Revise all topics and try again — you can do this!'; color='var(--danger)'; }

  document.getElementById('grade-letter').textContent = grade;
  document.getElementById('grade-pct').textContent = pct+'%';
  document.getElementById('grade-circle').style.borderColor = color;
  document.getElementById('grade-letter').style.color = color;
  document.getElementById('result-title').textContent = title;
  document.getElementById('result-subtitle').textContent = subtitle;
  document.getElementById('rs-correct').textContent = correctCount;
  document.getElementById('rs-wrong').textContent = total-correctCount;
  document.getElementById('rs-total').textContent = total;

  // Motivation
  const banner = document.getElementById('motivation-banner');
  if(maxStreak>=5){
    banner.innerHTML = `<strong>🔥 ${maxStreak}-Question Streak!</strong>You hit a great streak during this quiz — that's real momentum!`;
    banner.classList.add('show');
  }

  // Section breakdown
  const bRows = document.getElementById('breakdown-rows');
  bRows.innerHTML = '';
  Object.keys(sectionScores).forEach(sec=>{
    const sc = sectionScores[sec];
    if(sc.t===0) return;
    const p = Math.round((sc.c/sc.t)*100);
    const barColor = p>=80?'var(--green)':p>=60?'var(--primary)':'var(--danger)';
    bRows.innerHTML += `
      <div class="breakdown-row">
        <div class="breakdown-label">${sec}</div>
        <div class="breakdown-bar-wrap"><div class="breakdown-bar" style="width:${p}%;background:${barColor}"></div></div>
        <div class="breakdown-pct">${sc.c}/${sc.t}</div>
      </div>`;
  });

  if(!partialRun) Object.keys(sectionScores).forEach(sec=>{
    const sc = sectionScores[sec]; if(!sc.t) return;
    const pp = Math.round(sc.c/sc.t*100), old = saved.sec[sec];
    saved.sec[sec] = { best: Math.max(pp, old ? old.best : 0), last: pp };
  });
  persist();
  document.getElementById('retry-btn').style.display = (total-correctCount) > 0 ? '' : 'none';
  showScreen('screen-results');
}

// ═══════════════════════════════════════════════════════════
//  REVIEW
// ═══════════════════════════════════════════════════════════
function showReview(bookmarksOnly=false){
  reviewMode = bookmarksOnly;
  document.getElementById('review-screen-title').textContent = bookmarksOnly ? 'Bookmarked questions' : 'Review all answers';
  renderReviewList('all');
  showScreen('screen-review');
}
function showBookmarks(){ showReview(true); }

function renderReviewList(filter){
  const list = document.getElementById('review-list');
  list.innerHTML='';
  const labels=['A','B','C','D'];

  quizQuestions.forEach((q,i)=>{
    if(reviewMode && !bookmarks.has(q._i)) return;
    const ua = userAnswers[i];
    const isCorrect = ua===q.answer;
    const isSkip = ua===-1||ua===null;

    if(filter==='wrong' && (isCorrect||isSkip)) return;
    if(filter==='correct' && !isCorrect) return;

    const badgeClass = isSkip?'badge-skip':isCorrect?'badge-correct':'badge-wrong';
    const badgeTxt = isSkip?'Skipped':isCorrect?'Correct':'Wrong';

    list.innerHTML += `
      <div class="review-item">
        <div class="review-item-header">
          <div class="review-q-text">Q${i+1}. ${q.question}</div>
          <span class="review-badge ${badgeClass}">${badgeTxt}</span>
        </div>
        <div class="review-answers">
          ${!isSkip&&!isCorrect?`<div class="ra-wrong">Your answer: ${labels[ua]}. ${q.options[ua]}</div>`:''}
          <div class="ra-correct">✓ Correct: ${labels[q.answer]}. ${q.options[q.answer]}</div>
          <div class="ra-exp">💡 ${q.explanation}</div>
        </div>
      </div>`;
  });
  if(list.innerHTML==='') list.innerHTML='<div style="text-align:center;color:var(--muted);padding:30px;font-size:0.88rem;">No questions to show here.</div>';
}

function filterReview(type, el){
  document.querySelectorAll('.filter-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  renderReviewList(type);
}

function backToResults(){ showScreen('screen-results'); }

// ═══════════════════════════════════════════════════════════
//  SCREEN MANAGEMENT
// ═══════════════════════════════════════════════════════════
function showScreen(id){
  document.querySelectorAll('.pq-screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  window.scrollTo(0,0);
}
function goHome(){
  rebuildGridKeepingSelection(); updateBmButton();
  clearCountdown();
  document.getElementById('timer-display').style.display='none';
  document.getElementById('motivation-banner').classList.remove('show');
  showScreen('screen-welcome');
}
function restartQuiz(){
  document.getElementById('motivation-banner').classList.remove('show');
  startQuiz();
}

updateBmButton();
